console.log("testing")
console.log("rendering")
var one = "javascript"
console.log(one)

console.log(window.one+" window")

function abc(){
    var two = "JSW"
    console.log(two)
}
abc()

const a='test 1 1 1 '
console.log(window.a)  // global declaration

function t(){
    const n = "qwerty"
    console.log(n)
}
t()
const n="123"
console.log(n)

if(1==1){
    const m="asdfg"
    console.log(m)
    
}
