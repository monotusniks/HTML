// HTML file associated to it is - Practice.html
import {PI, add} from './utils.js'
console.log(PI)
console.log(add(2,3))

// Adding query selector examples here.

let vari1 = document.querySelector('p')
console.log(vari1)
vari1.style.color='red'

let vari2 = document.querySelectorAll('div')
console.log(vari2)