// this is an example for null vs undefined

console.log(3==3)
console.log("text")