var a="test"   
console.log(typeof a)

// big int
var b=10n
console.log(typeof b)

// string
var c= "test"
console.log(typeof c)

//boolean
var d= true
console.log(typeof d )

//undefined
var z
console.log(typeof z) 

//object 
var obj={}
console.log(typeof obj)

//array
var arr=[]
console.log(typeof arr)

//symbol
var sym= Symbol("id")
console.log(typeof sym)

//null
var e =10
e=null
console.log(typeof e)